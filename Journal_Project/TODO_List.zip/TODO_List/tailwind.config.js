/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './todo_app/templates/**/*.html',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

